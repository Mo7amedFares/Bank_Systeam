#pragma once
#include "clsUser.h"
clsUser CurrentUser = clsUser::GetEmptyUserObject();